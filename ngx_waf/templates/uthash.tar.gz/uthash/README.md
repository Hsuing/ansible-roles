
[![Build status](https://api.travis-ci.org/troydhanson/uthash.svg?branch=master)](https://travis-ci.org/troydhanson/uthash)

Documentation for uthash is available at:

https://troydhanson.github.io/uthash/


