
sqli_fingerprints = set([
'1234'
])
